#include<stdio.h>
#include<conio.h>
int main()
{
	int n;
	printf("enter a number:");
	scanf("%d",&n);
	for(n;n<=100;n++){
	if((n%15)==0)
	{
		printf("fizz buff\t");
	}
	else if(n%3==0)
	{
		printf("fizz\t");
	}
	else if(n%5==0)
	{
		printf("buff\t");
	}
	else
	{
		printf("%d \t",n);
	}
}
	return 0;
}
	
